library(testthat)
library(sva)

test_check("sva")
